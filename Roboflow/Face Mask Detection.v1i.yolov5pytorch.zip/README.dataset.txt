# Face Mask Detection 3 > 2022-08-01 12:54pm
https://universe.roboflow.com/object-detection/face-mask-detection-3-mhwdc

Provided by Roboflow
License: CC BY 4.0

